(function() {
  var sectionClass = "__clicker__section",
    sectionSelector =
      ".Post div[data-click-id='body']:not(." + sectionClass + ")",
    setupElement = function(element) {
      element.querySelectorAll(sectionSelector).forEach(function(e) {
        e.classList.add(sectionClass);
      });
    },
    observer = new MutationObserver(function(mutationRecord) {
      mutationRecord.forEach(function(mutation) {
        if (mutation.addedNodes) {
          mutation.addedNodes.forEach(function(node) {
            node.nodeType === 1 ? setupElement(node) : 0;
          });
        } else if (mutation.target) {
          setupElement(mutation.target);
        }
      });
    });

  setupElement(document);

  observer.observe(document.getElementById("SHORTCUT_FOCUSABLE_DIV"), {
    attributes: false,
    childList: true,
    subtree: true
  });
})();
