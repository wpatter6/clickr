(function() {
  var sectionClass = "__clicker__section",
    sectionSelector =
      ".TwitterCard:not(." +
      sectionClass +
      "), .tweet:not(." +
      sectionClass +
      ")", //insert site specific up/down selectors
    //focusClass = "__clicker__focus",
    //focusSelector = ".content img:not(" + focusClass + ")",
    setupElement = function(element) {
      element.querySelectorAll(sectionSelector).forEach(function(e) {
        e.classList.add(sectionClass);
      });

      /* document.querySelectorAll(focusSelector).forEach(function (e) {
        e.classList.add(focusClass);
      }); */
    },
    observer = new MutationObserver(function(mutationRecord) {
      mutationRecord.forEach(function(mutation) {
        if (mutation.addedNodes) {
          mutation.addedNodes.forEach(function(node) {
            node.nodeType === 1 ? setupElement(node) : 0;
          });
        } else if (mutation.target) {
          setupElement(mutation.target);
        }
      });
    });

  setupElement(document);

  observer.observe(document.body, {
    attributes: false,
    childList: true,
    subtree: true
  });

  console.log("Clicker - Twitter content script loaded.");
})();
