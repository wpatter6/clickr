(function() {
  var sectionClass = "__clicker__section__exclusive",
    sectionSelector =
      "header, footer, .Nav, .MastheadTileContent, .Masthead__actionMenu, .WindowedList, .SimpleModalNav, .SimpleCollection__sponsored-tile, .AllUpGrid, .Slider__items:not(." +
      sectionClass +
      ")",
    highlightClass = "__clicker__highlighted",
    playVideoClass = "__clicker__playvideo",
    playVideoSelector = "button.HoverSetup__button",
    playButtonClass = "__clicker__playbutton",
    pauseButtonClass = "__clicker__pausebutton",
    playButtonSelector =
      ".controls__playback-button-paused:not(." + playButtonClass + ")",
    pauseButtonSelector =
      ".controls__playback-button-paused:not(." + pauseButtonClass + ")",
    setupElement = function(element, added) {
      element.querySelectorAll(sectionSelector).forEach(function(e) {
        e.classList.add(sectionClass);
      });

      element.querySelectorAll(playButtonSelector).forEach(function(e) {
        e.classList.add(playButtonClass);
      });

      element.querySelectorAll(pauseButtonSelector).forEach(function(e) {
        e.classList.add(pauseButtonClass);
      });

      element
        .querySelectorAll(playVideoSelector + ":not(" + playVideoClass + ")")
        .forEach(function(e) {
          e.classList.add(playVideoClass);

          e.addEventListener("click", function() {
            const a = e.nextSibling.querySelector("a");
            a.classList.add(highlightClass);
            a.focus();
          });

          e.addEventListener("focus", function() {
            const selected = [].slice.call(
              document.querySelectorAll(
                ".GenericTile__container--hover.HoverSetup--hover,.VerticalCoverStoryTile--hover.HoverSetup--hover"
              )
            );
            selected.forEach(function(e) {
              e.classList.remove(
                "GenericTile__container--hover",
                "HoverSetup--hover",
                "VerticalCoverStoryTile--hover",
                "HoverSetup--hover"
              );
            });
          });
        });

      var autoClickClass = "__clicker__autoclick",
        autoClickButtonSelector =
          ".SliderV2__button:not(" + autoClickClass + ")",
        autoClickButtons = [].slice.call(
          element.querySelectorAll(autoClickButtonSelector)
        );

      autoClickButtons.forEach(function(e) {
        e.addEventListener("focus", function() {
          const section = e.parentNode.querySelector("." + sectionClass),
            isPrev = e.classList.contains("Slider__button--previous");
          e.click();
          if (section) {
            setTimeout(
              function(section) {
                let button = section.querySelector(playVideoSelector);
                if (isPrev) {
                  const buttons = section.querySelectorAll(playVideoSelector);
                  button = buttons[buttons.length - 1];
                }
                button.classList.add(highlightClass);
                button.focus();
              },
              700,
              section
            );
          }
        });
      });

      if (added && element.matches(".L2Content.addFocus.Details")) {
        const button = element.querySelector(".WatchAction__btn");
        button.classList.add(highlightClass);
        button.focus();
      }
    },
    observer = new MutationObserver(function(mutationRecord) {
      console.log("mutation!", mutationRecord);
      mutationRecord.forEach(function(mutation) {
        if (mutation.addedNodes && mutation.addedNodes.length) {
          mutation.addedNodes.forEach(function(node) {
            [1, 9].indexOf(node.nodeType) !== -1 ? setupElement(node, true) : 0;
          });

          if (
            mutation.addedNodes[0].nodeType === 1 &&
            mutation.addedNodes[0].matches(".GenericTileThumbnail__rollover")
          ) {
            setTimeout(() => {
              var link = mutation.addedNodes[0].querySelector(
                "a.GenericTileThumbnail"
              );
              if (link) {
                link.classList.add(highlightClass);
                link.focus();
              }
            }, 100);
          }
        } else if (mutation.target) {
          setupElement(mutation.target);
        }
      });
    });

  setupElement(document);

  observer.observe(document.body, {
    attributes: false,
    childList: true,
    subtree: true
  });

  console.log("Clicker - Hulu content script loaded.");
})();
