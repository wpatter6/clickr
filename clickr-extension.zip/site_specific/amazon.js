(function() {
  var highlightClass = "__clicker__highlighted",
    sectionClass = "__clicker__section__exclusive",
    sectionSelector =
      "header, footer, section, #Subnav, #navFooter, .DigitalVideoUI_Carousel__carousel, .dv-action-box, .s-result-item, .a-section, .gw-card-layout",
    displayBlockSelector = ".DigitalVideoWebNodeStorefront_Card__Packshot > a",
    instantFocusSelector = "a[data-video-type='Feature']",
    setupElement = function(element) {
      element.querySelectorAll(sectionSelector).forEach(function(e) {
        e.classList.add(sectionClass);
      });

      element.querySelectorAll(displayBlockSelector).forEach(function(e) {
        e.style.display = "block";
      });

      element.querySelectorAll(instantFocusSelector).forEach(function(e, i) {
        if (i === 0) {
          e.classList.add(highlightClass);
          e.focus();
        }
      });
    },
    observer = new MutationObserver(function(mutationRecord) {
      mutationRecord.forEach(function(mutation) {
        if (mutation.addedNodes) {
          mutation.addedNodes.forEach(function(node) {
            node.nodeType === 1 ? setupElement(node) : 0;
          });
        } else if (mutation.target) {
          setupElement(mutation.target);
        }
      });
    });

  setupElement(document);

  observer.observe(document.body, {
    attributes: false,
    childList: true,
    subtree: true
  });
})();
