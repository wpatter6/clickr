(function() {
  var sectionClass = "__clicker__section",
    modifiedClass = "__clicker__modified",
    highlightClass = "__clicker__highlighted",
    sectionSelector =
      ".slider:not(." +
      sectionClass +
      "), .billboard-row:not(." +
      sectionClass +
      "), .billboard-links:not(." +
      sectionClass +
      "), .main-header:not(." +
      sectionClass +
      "), .overview:not(." +
      sectionClass +
      ")",
    linkSelector = ".title-card-container a:not(." + modifiedClass + ")",
    setupElement = function(element) {
      element.querySelectorAll(sectionSelector).forEach(function(e) {
        e.classList.add(sectionClass);
      });

      element.querySelectorAll(linkSelector).forEach(function(e) {
        e.classList.add(modifiedClass);

        e.addEventListener("click", function() {
          setTimeout(function() {
            var playLink = document.querySelector(
              ".jawBoneContent.open a[data-uia='play-button']"
            );
            if (playLink) {
              playLink.parentNode.classList.add(highlightClass);
              playLink.focus();
            }
          }, 1000);
        });
      });
    },
    observer = new MutationObserver(function(mutationRecord) {
      mutationRecord.forEach(function(mutation) {
        if (mutation.addedNodes) {
          mutation.addedNodes.forEach(function(node) {
            node.nodeType === 1 ? setupElement(node) : 0;
          });
        } else if (mutation.target) {
          setupElement(mutation.target);
        }
      });
    });

  setupElement(document);

  observer.observe(document.body, {
    attributes: false,
    childList: true,
    subtree: true
  });
})();
