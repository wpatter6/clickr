(function() {
  var highlightClass = "__clicker__highlighted",
    sectionClass = "__clicker__section",
    sectionSelector =
      ".class1:not(." +
      sectionClass +
      "), .class2.class4:not(." +
      sectionClass +
      "):not(a)",
    addTabIndexSelector = "[style*='pointer;']",
    setupElement = function(element) {
      element.querySelectorAll(sectionSelector).forEach(function(e) {
        var style = getComputedStyle(e),
          image = style.getPropertyValue("background-image"),
          size = style.getPropertyValue("width");

        if (image.indexOf("btn_dot_default") === -1 && size !== "8px") {
          e.classList.add(sectionClass);
        }
      });

      document.querySelectorAll(addTabIndexSelector).forEach(function(e) {
        var closest = e.parentElement.closest(addTabIndexSelector);
        if (!closest) {
          e.setAttribute("tabindex", "0");
        }
      });
    },
    observer = new MutationObserver(function(mutationRecord) {
      console.log("mutated", mutationRecord);
      mutationRecord.forEach(function(mutation) {
        if (mutation.addedNodes) {
          mutation.addedNodes.forEach(function(node) {
            node.nodeType === 1 ? setupElement(node) : 0;
          });
        } else if (mutation.target) {
          setupElement(mutation.target);
        }

        if (mutation.target.matches(".class27")) {
          var el = mutation.target.querySelector("a");
          if (el) {
            el.classList.add(highlightClass);
            el.focus();
          }
        }
      });
    });

  setupElement(document);

  observer.observe(document.body, {
    attributes: false,
    childList: true,
    subtree: true
  });

  console.log("Clicker - HBO Now content script loaded.");
})();
